package com.example.practicaltestaab.presentation.main

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.practicaltestaab.data.local.preferences.MyAdapter
import com.example.practicaltestaab.databinding.ActivityMainBinding
import com.example.practicaltestaab.domain.model.Quote
import com.example.practicaltestaab.domain.useCases.room.GetBankUseCase
import com.example.practicaltestaab.domain.useCases.room.GetRandomQuoteUseCase
import com.example.practicaltestaab.presentation.mainactivity.MainPresenter
import com.example.practicaltestaab.presentation.ui.BankViewModel
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

//@AndroidEntryPoint
//@HiltAndroidApp
class MainActivity : AppCompatActivity() {
    private val TAG = "MainActivity"
    var result: ArrayList<Quote> = ArrayList()
    private lateinit var binding: ActivityMainBinding
    var mainPresenter: MainPresenter = MainPresenter()
//    val viewModel = ViewModelProvider(this)[BankViewModel::class.java]
//    private val viewModel: BankViewModel by viewModels()
    var viewModel = ViewModelProvider.of(this).get(BankViewModel::class.java)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        principalThread()


    }

    fun principalThread() {
        CoroutineScope(Dispatchers.IO).launch {
            result = mainPresenter.showList(this@MainActivity)
            runOnUiThread {
                val adapter = MyAdapter(this@MainActivity, result)
                binding.listBanksObject.adapter = adapter
            }
        }
        consumoBD()
    }


    fun consumoBD() {
        viewModel.onCreate()
        viewModel.quoteModel.observe(this, Observer {
//            binding.tvQuote.text = it.quote
//            binding.tvAuthor.text = it.author
        })
        viewModel.isLoading.observe(this, Observer {
            binding.loading.isVisible = it
        })
//        binding.viewContainer.setOnClickListener { quoteViewModel.randomQuote() }
//    }
    }
}

