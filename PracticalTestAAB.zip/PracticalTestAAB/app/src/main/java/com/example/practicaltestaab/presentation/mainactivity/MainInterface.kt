package com.example.practicaltestaab.presentation.mainactivity

interface MainInterface